package com.app.tests;
/**
 * 
 * This class contains test Data and locaters
 * @author ashok.kumar
 *
 */
public class TestUtils {
	public static String URL = "https://www.flipkart.com/";
	public static String DRIVER_PATH = "E:\\ccjar\\chromedriver.exe";
	public static String SHOES = "shoes";
	public static String FKTITLE = "Online Shopping Site for Mobiles, Electronics, Furniture, Grocery, Lifestyle, Books & More. Best Offers!";
	public static String FKTITLE_SHOES = "shoes";
	public static String SBRAND="Puma";
	public static String EPRICE="Min-₹1500";
	public static String LOGINTITLE="LOGIN OR SIGNUP";
	
	
	public static String ESC = "//*[@class='_32LSmx']";
	public static String SEARCH_INPUT = "//*[@name='q']";
	public static String SEARCH_TITLE ="//*[@class='_2yAnYN']/span";
	public static String FILTER_BRAND ="//*[@placeholder='Search Brand']";
	public static String CHKBOX_BRAND ="//*[@class='-FTLnR']/following-sibling::div[1]";
	public static String PRICESB ="(//*[@class='fPjUPw'])[2]";
	public static String SETPRICE="1500";
	public static String VERIFY_PRICESB ="(//*[@class='_3UZZGt'])[1]";
	public static String VERIFY_BRAND ="(//*[@class='_3UZZGt'])[2]";
	public static String SETSIZE ="//*[@id='swatch-1-size']/a";
	public static String BUYBUTTON ="//*[@class='_2AkmmA _2Npkh4 _2kuvG8 _7UHT_c']";
	public static String PRODLIST ="((//*[@class='_1HmYoV _35HD7C'])[2]/div[2]/div/div/div/a)";
	public static String LOGINPAGETITLE ="(//h3/span[2])[1]";
	
	
	
	
	
	
	
	
	
	public static Object[][] dataToTest;

	
	
}
